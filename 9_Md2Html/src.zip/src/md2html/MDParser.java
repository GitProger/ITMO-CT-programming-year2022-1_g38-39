package md2html;

import java.util.*;
import java.util.regex.*;

public class MDParser {
    private static class Pair<A, B> {
        public final A first;
        public final B second;
        public Pair(A first, B second) {
            this.first = first;
            this.second = second;
        }
    }

//    private static final String RED = "\u001B[31;1m";
//    private static final String GREEN = "\u001B[32m";
//    private static final String YELLOW = "\u001B[33m";
//    private static final String BLUE = "\u001B[34m";
//    private static final String PURPLE = "\u001B[35m";
//    private static final String CYAN = "\u001B[36m";
//    private static final String WHITE = "\u001B[37m";
//    private static final String END = "\u001B[0m";

    private final String markdown;
    private final String html;

    public MDParser(String md) {
        this.markdown = md;
        this.html = parse(md);
    }

    public String toMarkdown() {
        return markdown;
    }

    public String toHTML() {
        return html;
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private static String x2(String a) {
        return a + a;
    }

    private static <T> ArrayList<T> zip(List<T> a, List<T> b) {
        ArrayList<T> res = new ArrayList<>();
        for (int i = 0; i < Math.max(a.size(), b.size()); i++) {
            if (i < a.size()) res.add(a.get(i));
            if (i < b.size()) res.add(b.get(i));
        }
        return res;
    }
    private static <T> ArrayList<T> zip(Pair<List<T>, List<T>> p) {
        return zip(p.first, p.second);
    }

    private static Pair<List<String>, List<String>> split(String text, String regex) {
         List<String> noMatch = Arrays.asList(text.split(regex));
         List<String> allMatch = new ArrayList<String>();
         Matcher m = Pattern.compile(regex).matcher(text);
         while (m.find()) {
             allMatch.add(m.group());
         }
         return new Pair<>(noMatch, allMatch);
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /*
     *    \*((.|\s)+)\*  _((.|\s)+)_ \*\*((.|\s)+)\*\* __((.|\s)+)__
     *    \-\-((.|\s)+)\-\-
     *    `((.|\s)+)`
     *    \[ (process) \]\( (href) \)
     */
    private final static Map<String, HtmlTagTable> tagByMD = Map.of(
        "**", HtmlTagTable.STRONG,
        "__", HtmlTagTable.STRONG_,
        "*", HtmlTagTable.EMPHASIS,
        "_", HtmlTagTable.EMPHASIS_,
        "--", HtmlTagTable.STRIKEOUT,
        "`", HtmlTagTable.CODE
    );


    private ArrayList<DocumentNode> process(String src, String regex) {
        var all = split(src, regex);
        var noMatches = all.first;
        var matches = all.second;

//        System.out.println(GREEN + "noMatches: " + String.join(";", noMatches) + END);
//        System.out.println(GREEN + "matches: " + String.join(";", matches) + END);

        List<DocumentNode> matchModified = new ArrayList<>();
        for (var particularMatch : matches) {
            Pattern paragraph = Pattern.compile("^" + regex + "$");
            Matcher matcher = paragraph.matcher(particularMatch);
            if (!matcher.matches()) throw new RuntimeException("An error occurred while regex were processing.");
//            System.out.println(YELLOW + "^" + regex + "$ <<" + particularMatch + ">> g: " + matcher.groupCount() + END);
//            for (int i = 0; i < matcher.groupCount(); i++)  System.out.println(PURPLE + matcher.group(i) + END);
            matchModified.add(new DocumentNode(
                    process(matcher.group(2), regex),
                    tagByMD.get(matcher.group(1)),
                    new HashMap<>()
            ));
        }

        List<DocumentNode> noMatchModified = new ArrayList<>();
        for (var particularNoMatch : noMatches) {
            noMatchModified.add(new Text(particularNoMatch));
        }

        return zip(noMatchModified, matchModified);
    }



    private ArrayList<DocumentNode> parseParticularParagraph(String src) { // добавить экраинрование
//        System.out.println(RED + "to parse: " + END + src);
        final String whatever = "([\\S\\s]+?)"; // "((.|\\s)+?)"; // `.` cannot be `\n`
        final String shield = "(?<!\\\\)";
        return process(src,
             "(" + String.join("|", new String[]{
                     "\\*\\*", "__",  shield + "\\*",  shield + "_", "\\-\\-", "`"
             })  + ")"
             + whatever + shield + "\\1" // но shield добавит также экранирование `** text \**` -bad? | `* text \**` - OK
                // ? для ленивости https://javarush.ru/groups/posts/regulyarnye-vyrazheniya-v-java
                // "*a **b** c*"
        );
        // (?<[^*])(\*)([^*][\\s\\S]*[^*])\1(?[^*])
    }
//  [^*] * [^*]+ * [^*]


    private Paragraph parseHeader(String src) {
        Pattern header = Pattern.compile("^(#+)\\s+((.|\\s)+)$");
        Matcher matcher = header.matcher(src);
        if (matcher.matches()) {
            return new Paragraph(
                    (int)matcher.group(1).chars().filter(ch -> ch == '#').count(),
                    parseParticularParagraph(matcher.group(2)) // было List.of(new Text(matcher.group(2))), не работали выделения в заголовке
            );
        }
        return new Paragraph(0, parseParticularParagraph(src));
    }

    private String parse(String md) {
        /*
         * [Text](Link)     - <a href="Link">
         */
        var paragraphs = new ArrayList<Paragraph>();
        var parted = md.split(x2(System.lineSeparator()));
        for (String paragraphSource : Arrays.stream(parted).filter(s -> !s.trim().isEmpty()).toArray(String[]::new)) {
            paragraphs.add(parseHeader(paragraphSource.replaceFirst("\\s++$", "").replaceFirst("^\\n++", ""))); // remove \n from end
        }

        return new HTMLDocument(paragraphs).toHTML();
    }
}
