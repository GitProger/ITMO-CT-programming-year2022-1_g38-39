package md2html;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class Md2Html {
    public static String readFromFile(String fName) {
        try {
            InputStreamReader reader = new InputStreamReader(new FileInputStream(fName), StandardCharsets.UTF_8);
            StringWriter buffer = new StringWriter();
            char[] bufferArray = new char[8 * 1024];
            int chars = reader.read(bufferArray);
            while (chars >= 0) {
                buffer.write(bufferArray, 0, chars);
                chars = reader.read(bufferArray);
            }
            return buffer.toString();
        } catch (FileNotFoundException e) {
            System.out.printf("'%s' does not exist.%n", fName);
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return "";
    }
    public static void printToFile(String fileName, String s) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
            writer.write(s);
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public Md2Html(String mdFileName, String htmlFileName) {
        printToFile(htmlFileName, new MDParser(readFromFile(mdFileName)).toHTML());
    }

    private static int test = 0;
    public static void main(String[] args) {
        test++;
        printToFile("/tmp/input" + test + ".txt", readFromFile(args[0]));
        printToFile("/tmp/output" + test + ".txt", new MDParser(readFromFile(args[0])).toHTML());

        //args = new String[] {"input.md", "output.html"};
        printToFile(args[1], new MDParser(readFromFile(args[0])).toHTML());
    }
}
/*

'* text *' -> '* text *'
'*text*' -> '<em>text</em'

 */