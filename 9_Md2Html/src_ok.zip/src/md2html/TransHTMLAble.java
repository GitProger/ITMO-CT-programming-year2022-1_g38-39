package md2html;

public interface TransHTMLAble {
    String toHTML();
}
